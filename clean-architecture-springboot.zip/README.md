# Clean Architecture - Spring Boot Example

Este é um projeto exemplo usando Spring Boot e Clean Architecture, com PostgreSQL, Docker e CI básico com GitHub Actions.

## Como executar

1. Certifique-se de ter Docker e Docker Compose instalados.
2. Execute `docker-compose up` para subir o banco de dados PostgreSQL.
3. Rode o projeto com `./mvnw spring-boot:run` ou importe na sua IDE.

## Estrutura de Pastas

- `core/entity`: Entidades do domínio
- `core/usecase`: Casos de uso
- `entrypoint/controller`: Controllers REST
- `dataprovider/repository`: Implementações dos repositórios e integrações

## Stack
- Java 17
- Spring Boot 3.x
- PostgreSQL
- Docker
- GitHub Actions (CI)
